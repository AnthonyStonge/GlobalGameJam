﻿using UnityEngine;

namespace PixelCrushers.SceneStreamer
{
	[AddComponentMenu("Scene Streamer/Neighboring Scenes")]
 	public class NeighboringScenes : MonoBehaviour
 	{
 		public string[] sceneNames;
 	}
 
 }